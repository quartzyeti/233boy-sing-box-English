#!/bin/bash

args=$@
is_sh_ver=v1.03

. /etc/sing-box/sh/src/init.sh